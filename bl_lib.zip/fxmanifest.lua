fx_version 'cerulean'
game 'gta5'

description 'Shared library for bl resources'
author 'Bluey'
version '1.0.0'

shared_script 'lib.lua'
